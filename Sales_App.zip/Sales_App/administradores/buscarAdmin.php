<?php 
	include("../conexion.php");
 
	if (!$bdcon) //Si no es posible lograr la conexion devuelve un mensaje de error
	{
    	echo "Lo sentimos, este sitio está experimentando problemas";
    	exit;
	}
	else
	{
        $varIdAdmin = $_POST["idAdmin"];

        $sql = "SELECT * FROM v_Administradores WHERE Id_Admin = " . $varIdAdmin . ";"; 
        
        
    	$result = mysqli_query($conexion, $sql);
        while ($row = mysqli_fetch_assoc($result)) {

            $row_array['idAdmin'] = $row['Id_Admin'];
            $row_array['nombres'] = $row['Nombres'];
            $row_array['apellidos'] = $row['Apellidos'];
            $row_array['usuario'] = $row['Usuario'];
            $row_array['estado'] = filter_var($row['Estado'], FILTER_VALIDATE_BOOLEAN);
        }
        
		echo json_encode($row_array, 256);
    }
?>