﻿using ProyectoFinalGrupo4.Models;
using ProyectoFinalGrupo4.Respositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace ProyectoFinalGrupo4
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class DetallesProducto : ContentPage
    {
        Productos productoGlobal = new Productos();
        RepositoryDescuentos repositoryDescuentos = new RepositoryDescuentos();
        List<Descuentos> descuentos = new List<Descuentos>();

        public DetallesProducto(Productos producto)
        {
            InitializeComponent();
            productoGlobal = producto;
            imgProducto.Source = producto.fotoSource;
            txtNombreProducto.Text = producto.nombre;
            txtCategoriaProveedor.Text = producto.proveedor + " | " + producto.categoria;
            txtDescripcion.Text = producto.descripcion;
            txtCantidad.Text = "Cantidad Unidad: " + producto.cantidadUnidad;
            txtUnidades.Text = "Unidades Disponibles: " + producto.unidadesAlmacen;
            txtPrecio.Text = "L." + producto.precio;

            txtCantidadesCarrito.Text = "1";

            descuentos = repositoryDescuentos.LlenarDescuentos();
            if (descuentos.Count == 1)
            {
                cmbDescuentos.Title = "No hay descuentos aplicables actualmente";
                cmbDescuentos.SelectedItem = descuentos[0];
                cmbDescuentos.IsEnabled = false;
            }
            else
            {
                cmbDescuentos.ItemsSource = descuentos;
            }
            
        }

        private void Button_Back(object sender, EventArgs e)
        {
            this.Navigation.PopAsync();
        }

        private void SumarCantidad(object sender, EventArgs e)
        {
            if (int.Parse(txtCantidadesCarrito.Text) < productoGlobal.unidadesAlmacen)
            {
                int cantidad = int.Parse(txtCantidadesCarrito.Text) + 1;
                txtCantidadesCarrito.Text = cantidad + "";
            }
        }

        private void RestarCantidad(object sender, EventArgs e)
        {
            if (int.Parse(txtCantidadesCarrito.Text) > 0)
            {
                int cantidad = int.Parse(txtCantidadesCarrito.Text) - 1;
                txtCantidadesCarrito.Text = cantidad + "";
            }
        }

        private void AñadirCarrito (object sender, EventArgs e)
        {
            Descuentos descuento = (Descuentos) cmbDescuentos.SelectedItem;
            DisplayAlert("Descuento",descuento.descripcion,"Ok");
        }
    }
}