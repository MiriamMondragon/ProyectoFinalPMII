﻿using Newtonsoft.Json;
using ProyectoFinalGrupo4.Dependencies;
using ProyectoFinalGrupo4.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using Xamarin.Essentials;
using Xamarin.Forms;

namespace ProyectoFinalGrupo4.Respositories
{
    public class RepositoryProductos : ContentPage
    {
        private static readonly HttpClient client = new HttpClient();

        //METODOS
        public async void InsertProducto(Productos producto, int idUsuarioActual)
        {
            //INSERTA LOS DATOS
            string URL = EndPointsAPI.insertProducto;
            WebClient webClient = new WebClient();

            webClient.QueryString.Add("nombre", producto.nombre);
            webClient.QueryString.Add("descripcion", producto.descripcion);
            webClient.QueryString.Add("idCategoria", producto.idCategoria + "");
            webClient.QueryString.Add("idProveedor", producto.idProveedor + "");
            webClient.QueryString.Add("cantidadUnidad", producto.cantidadUnidad);
            webClient.QueryString.Add("unidadesAlmacen", producto.unidadesAlmacen + "");
            webClient.QueryString.Add("cantidadMinima", producto.cantidadMinima + "");
            webClient.QueryString.Add("cantidadMaxima", producto.cantidadMaxima + "");
            webClient.QueryString.Add("foto", producto.foto); //SI SE VA A ENVIAR NULL DEBE SER "null" como string
            webClient.QueryString.Add("precio", producto.precio + "");
            webClient.QueryString.Add("usuarioActual", idUsuarioActual + "");
            webClient.QueryString.Add("tipoDispositivo", DeviceInfo.Manufacturer + " " + DeviceInfo.Model);
            webClient.QueryString.Add("sistemaOperativo", DeviceInfo.Platform + " " + DeviceInfo.VersionString);

            var data = webClient.UploadValues(URL, "POST", webClient.QueryString);
            string responseString = UnicodeEncoding.UTF8.GetString(data);

            if (responseString.Equals("1"))
            {
                await App.Current.MainPage.DisplayAlert("Éxito", "Producto ingresado satisfactoriamente", "OK");
            }
            else
            {
                await App.Current.MainPage.DisplayAlert("Error", "No se ha guardado", "OK");
            }

        }

        public async void UpdateProducto(Productos producto, int idUsuarioActual)
        {
            //ACTUALIZA LOS DATOS
            string URL = EndPointsAPI.updateProducto;
            WebClient webClient = new WebClient();

            webClient.QueryString.Add("idProducto", producto.idProducto + "");
            webClient.QueryString.Add("nombre", producto.nombre);
            webClient.QueryString.Add("descripcion", producto.descripcion);
            webClient.QueryString.Add("idCategoria", producto.idCategoria + "");
            webClient.QueryString.Add("idProveedor", producto.idProveedor + "");
            webClient.QueryString.Add("cantidadUnidad", producto.cantidadUnidad);
            webClient.QueryString.Add("unidadesAlmacen", producto.unidadesAlmacen + "");
            webClient.QueryString.Add("cantidadMinima", producto.cantidadMinima + "");
            webClient.QueryString.Add("cantidadMaxima", producto.cantidadMaxima + "");
            webClient.QueryString.Add("foto", producto.foto); //SI SE VA A ENVIAR NULL DEBE SER "null" como string
            webClient.QueryString.Add("estado", producto.estado + "");
            webClient.QueryString.Add("precio", producto.precio + "");
            webClient.QueryString.Add("usuarioActual", idUsuarioActual + "");
            webClient.QueryString.Add("tipoDispositivo", DeviceInfo.Manufacturer + " " + DeviceInfo.Model);
            webClient.QueryString.Add("sistemaOperativo", DeviceInfo.Platform + " " + DeviceInfo.VersionString);

            var data = webClient.UploadValues(URL, "POST", webClient.QueryString);
            string responseString = UnicodeEncoding.UTF8.GetString(data);

            if (responseString.Equals("1"))
            {
                await App.Current.MainPage.DisplayAlert("Éxito", "Producto actualizado satisfactoriamente", "OK");
            }
            else
            {
                await App.Current.MainPage.DisplayAlert("Error", "No se ha guardado", "OK");
            }

        }

        public async void DeactivateProducto(Productos producto, int idUsuarioActual)
        {
            //SOLO REQUIERE EL ID DEL PRODUCTO
            string URL = EndPointsAPI.deactivateProducto;
            WebClient webClient = new WebClient();

            webClient.QueryString.Add("idProducto", 3 + "");
            webClient.QueryString.Add("usuarioActual", 1 + "");
            webClient.QueryString.Add("tipoDispositivo", DeviceInfo.Manufacturer + " " + DeviceInfo.Model);
            webClient.QueryString.Add("sistemaOperativo", DeviceInfo.Platform + " " + DeviceInfo.VersionString);

            var data = webClient.UploadValues(URL, "POST", webClient.QueryString);
            string responseString = UnicodeEncoding.UTF8.GetString(data);

            if (responseString.Equals("1"))
            {
                await App.Current.MainPage.DisplayAlert("Éxito", "Producto desactivado satisfactoriamente", "OK");
            }
            else
            {
                await App.Current.MainPage.DisplayAlert("Error", "No se ha desactivado", "OK");
            }

        }

        public List<Productos> ListProductos()
        {
            string URL = EndPointsAPI.listarProductos;
            WebClient webClient = new WebClient();

            List<Productos> listarProductos = new List<Productos>();

            var data = webClient.UploadValues(URL, "POST", webClient.QueryString);
            string responseString = UnicodeEncoding.UTF8.GetString(data);

            if (responseString.Equals(""))
            {
                App.Current.MainPage.DisplayAlert("Error", "No se pueden consultar los datos", "OK");
            }
            else
            {
                listarProductos = JsonConvert.DeserializeObject<List<Productos>>(responseString);
            }

            return listarProductos;
        }

        public Productos BuscarProductos(int idProducto)
        {
            string URL = EndPointsAPI.buscarProducto;
            WebClient webClient = new WebClient();

            webClient.QueryString.Add("idProducto", idProducto + "");

            var data = webClient.UploadValues(URL, "POST", webClient.QueryString);
            string responseString = UnicodeEncoding.UTF8.GetString(data);

            Productos producto = new Productos();
            if (responseString.Equals(""))
            {
                App.Current.MainPage.DisplayAlert("Error", "No se pueden consultar los datos", "OK");
            }
            else
            {
                producto = JsonConvert.DeserializeObject<Productos>(responseString);
            }

            return producto;
        }
    }
}