﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Xamarin.Forms;

namespace ProyectoFinalGrupo4.Dependencies
{
    class EndPointsAPI
    {
        public static String URL = "http://192.168.0.10:81/Sales_App/";

        //EndPoints de Administradores
        public static String verificarIde = URL + "administradores/verificarIdentificacion.php";
        public static String verificarUsuario = URL + "administradores/verificarUsuario.php";
        public static String insertAdmin = URL + "administradores/insertarAdmin.php";
        public static String updateAdmin = URL + "administradores/actualizarAdmin.php";
        public static String deactivateAdmin = URL + "administradores/desactivarAdmin.php";
        public static String listarAdmins = URL + "administradores/listarAdmins.php";
        public static String buscarAdmin = URL + "administradores/buscarAdmin.php";

    }
}