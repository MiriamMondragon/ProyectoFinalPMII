﻿namespace ProyectoFinalGrupo4.Models
{
    class MetodosPago
    {
        public int idMetodoPago { get; set; }
        public string metodoPago { get; set; }
    }
}
