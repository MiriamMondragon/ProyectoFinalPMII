﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProyectoFinalGrupo4.Models
{
    class MetodosPago
    {
        public int idMetodoPago { get; set; }
        public string metodoPago { get; set; }
    }
}
