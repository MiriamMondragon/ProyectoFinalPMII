﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProyectoFinalGrupo4.Models
{
    class Facturas
    {
        public int idFactura;
        public DateTime fecha;
        public string hora;
        public int idPersona;
        public string nombre;
        public int idUsuario;
        public string correo;
        public string latitud;
        public string longitud;
        public string metodoPago;
        public double subtotal;
        public double total;
    }
}
