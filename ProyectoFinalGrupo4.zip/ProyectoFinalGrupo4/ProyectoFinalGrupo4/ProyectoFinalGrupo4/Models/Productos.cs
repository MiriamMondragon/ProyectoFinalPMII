﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Xamarin.Forms;

namespace ProyectoFinalGrupo4.Models
{
    public class Productos
    {
        public int idProducto { get; set; }
        public string nombre { get; set; }
        public string descripcion { get; set; }
        public int idCategoria { get; set; }
        public string categoria { get; set; }
        public int idProveedor { get; set; }
        public string proveedor { get; set; }
        public string cantidadUnidad { get; set; } //DESCRIPCION DE LA UNIDAD (3 lb, 18 onzas, 3 paquetes, etc.)
        public int unidadesAlmacen { get; set; }
        public int cantidadMinima { get; set; }
        public int cantidadMaxima { get; set; }
        public string foto { get; set; }
        public bool estado { get; set; }
        public double precio { get; set; }

        public Productos()
        {
        }

        public Productos(string nombre, string descripcion, int idCategoria, int idProveedor, string cantidadUnidad, int unidadesAlmacen, int cantidadMinima, int cantidadMaxima, string foto, double precio)
        {
            this.nombre = nombre;
            this.descripcion = descripcion;
            this.idCategoria = idCategoria;
            this.idProveedor = idProveedor;
            this.cantidadUnidad = cantidadUnidad;
            this.unidadesAlmacen = unidadesAlmacen;
            this.cantidadMinima = cantidadMinima;
            this.cantidadMaxima = cantidadMaxima;
            this.foto = foto;
            this.precio = precio;
        }

        public Productos(int idProducto, string nombre, string descripcion, int idCategoria, string categoria, int idProveedor, string proveedor, string cantidadUnidad, int unidadesAlmacen, int cantidadMinima, int cantidadMaxima, string foto, bool estado, double precio)
        {
            this.idProducto = idProducto;
            this.nombre = nombre;
            this.descripcion = descripcion;
            this.idCategoria = idCategoria;
            this.categoria = categoria;
            this.idProveedor = idProveedor;
            this.proveedor = proveedor;
            this.cantidadUnidad = cantidadUnidad;
            this.unidadesAlmacen = unidadesAlmacen;
            this.cantidadMinima = cantidadMinima;
            this.cantidadMaxima = cantidadMaxima;
            this.foto = foto;
            this.estado = estado;
            this.precio = precio;
        }
    }
}