﻿using System;

namespace ProyectoFinalGrupo4.Models
{
    public class MenuLateral
    {
        public String Titulo { get; set; }
        public Type Pagina { get; set; }
    }
}
