﻿using ProyectoFinalGrupo4.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Essentials;
using Xamarin.Forms;

namespace ProyectoFinalGrupo4
{
    public partial class MainPage : ContentPage
    {
        Administradores administrador = new Administradores();
        RepositoryAdministradores repository = new RepositoryAdministradores();
        public MainPage()
        {
            InitializeComponent();
            
            List<Administradores> administradores = new List<Administradores>();
            /* ESTO ES PARA LLAMAR A TODA LA LISTA
            administradores = repository.ListAdministradores();
            lstAdministradores.ItemsSource = administradores;
            */
            administradores.Add(repository.BuscarAdministrador(1));
            lstAdministradores.ItemsSource = administradores;

        }

        private void Button_Clicked(object sender, EventArgs e)
        {
            repository.InsertAdministrador(administrador, 1);
        }

        private void Button_Clicked_1(object sender, EventArgs e)
        {
            repository.UpdateAdministrador(administrador, 1);
        }

        private void Button_Clicked_2(object sender, EventArgs e)
        {
            repository.DeactivateAdministrador(administrador, 1);
        }
    }
}
